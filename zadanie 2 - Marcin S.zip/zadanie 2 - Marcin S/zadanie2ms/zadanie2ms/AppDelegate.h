//
//  AppDelegate.h
//  zadanie2ms
//
//  Created by student on 11/10/2021.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

