//
//  SceneDelegate.h
//  zadanie2ms
//
//  Created by student on 11/10/2021.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

