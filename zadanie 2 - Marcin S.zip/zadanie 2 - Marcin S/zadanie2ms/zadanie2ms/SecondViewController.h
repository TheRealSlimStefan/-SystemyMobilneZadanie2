//
//  SecondViewController.h
//  zadanie2ms
//
//  Created by student on 11/10/2021.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@class SecondViewController;

@protocol SecondViewControllerDelegate <NSObject>

-(void) addItemViewController:(SecondViewController *) controller didFinishEnteringItem: (NSString *) item;
@end

@interface SecondViewController : UIViewController

@property NSString *surname;

@property (nonatomic, weak) IBOutlet UITextField *modifiedSurnameInputField;

@property (nonatomic, weak) id <SecondViewControllerDelegate> delegate;

-(IBAction)enter;

@end





NS_ASSUME_NONNULL_END
